package archeologicalExcavations;

public class Main {
    public static void main(String[] args) {

    }
}
